apt-get update -y
echo " "
apt-get upgrade -y
echo " "
pkg install figlet -y
echo " "
pkg install toilet -y
echo " "
pkg install cowsay -y
echo " "
pkg install nano -y
echo " "
pkg install ruby -y
echo " "
gem install lolcat
echo " "
pkg install nano -y
echo ""
pkg install mpv -y
echo " "